const express = require('express');
const path = require('path');
const Database = require('better-sqlite3');
const session = require('express-session');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const SESSION_SECRET = process.env.SESSION_SECRET;

if (!ADMIN_PASSWORD || ADMIN_PASSWORD.length < 16) {
  console.error('Set ADMIN_PASSWORD to a strong password of at least 16 characters.');
  process.exit(1);
}
if (!SESSION_SECRET || SESSION_SECRET.length < 32) {
  console.error('Set SESSION_SECRET to a random secret of at least 32 characters.');
  process.exit(1);
}

app.set('trust proxy', 1); // Needed by many HTTPS hosting platforms.
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '10kb' }));
app.use(session({
  name: 'private_messages_session',
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict',
    maxAge: 2 * 60 * 60 * 1000
  }
}));

const db = new Database(path.join(__dirname, 'messages.db'));
db.pragma('journal_mode = WAL');
db.exec(`CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  message TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
)`);

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: true, legacyHeaders: false });
const sendLimiter = rateLimit({ windowMs: 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false });

function requireAdmin(req, res, next) {
  if (req.session && req.session.isAdmin === true) return next();
  return res.status(401).json({ error: 'يلزم تسجيل الدخول' });
}

app.post('/api/login', loginLimiter, (req, res, next) => {
  const supplied = typeof req.body.password === 'string' ? req.body.password : '';
  const a = Buffer.from(supplied);
  const b = Buffer.from(ADMIN_PASSWORD);
  const valid = a.length === b.length && require('crypto').timingSafeEqual(a, b);
  if (!valid) return res.status(401).json({ error: 'كلمة المرور غير صحيحة' });
  req.session.regenerate(err => {
    if (err) return next(err);
    req.session.isAdmin = true;
    req.session.save(err2 => {
      if (err2) return next(err2);
      res.json({ ok: true });
    });
  });
});

app.post('/api/logout', requireAdmin, (req, res, next) => {
  req.session.destroy(err => {
    if (err) return next(err);
    res.clearCookie('private_messages_session', { httpOnly: true, sameSite: 'strict', secure: process.env.NODE_ENV === 'production' });
    res.json({ ok: true });
  });
});

// Public endpoint: visitors may send a message, but never read messages.
app.post('/api/messages', sendLimiter, (req, res) => {
  const message = typeof req.body.message === 'string' ? req.body.message.trim() : '';
  if (!message) return res.status(400).json({ error: 'الرسالة فارغة' });
  if (message.length > 5000) return res.status(413).json({ error: 'الرسالة طويلة جداً' });
  const result = db.prepare('INSERT INTO messages (message) VALUES (?)').run(message);
  res.json({ ok: true, id: result.lastInsertRowid });
});

// Private endpoint: only an authenticated admin session can read messages.
app.get('/api/messages', requireAdmin, (req, res) => {
  const rows = db.prepare('SELECT id, message, created_at FROM messages ORDER BY id DESC LIMIT 500').all();
  res.set('Cache-Control', 'no-store');
  res.json(rows);
});

app.use(express.static(path.join(__dirname, 'public')));
app.get('/health', (_req, res) => res.json({ ok: true }));
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: 'حدث خطأ داخلي' });
});

app.listen(PORT, () => console.log(`Private messages server listening on port ${PORT}`));
